import java.text.SimpleDateFormat;
import java.util.Date;

//Classe pessoa constru�da para ter um objeto pessoa como c�njuge

public class Pessoa {

	private String nome;
	private Date dataNcto;
	private String genero;
	private String cpf;
	private String endereco;
	private Pessoa conjuge;
	private String retorno;

	public Pessoa (String nome, Date dataNcto, String genero, String cpf, String endereco, Pessoa conjuge) {
		this.nome = nome;
		this.dataNcto = dataNcto;
		this.genero = genero;
		this.cpf = cpf;
		this.endereco = endereco;
		this.conjuge = conjuge;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Date getDataNcto() {
		return dataNcto;
	}

	public void setDataNcto(Date dataNcto) {
		this.dataNcto = dataNcto;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public Pessoa getConjuge() {
		return conjuge;
	}

	public void setConjuge(Pessoa conjuge) {
		this.conjuge = conjuge;
	}
	
	//imprime os dados de um objeto pessoa

	public String imprimirConjuge() {
		SimpleDateFormat sdf = new SimpleDateFormat ("dd/MM/yyyy");
		
		retorno = "\nNome: " + nome + "\nData nascimento: " + sdf.format(dataNcto) + "\nG�nero: " + genero + 
				"\nCPF: " + cpf + "\nEndere�o " + endereco + "\n";
	return retorno; 
	}

}
