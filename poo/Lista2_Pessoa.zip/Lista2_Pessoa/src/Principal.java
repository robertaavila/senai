import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Principal {

	public static void main(String[] args) throws ParseException {

		Pessoa pessoa = new Pessoa(null, null, null, null, null, null);

		System.out.println("Deseja cadastrar uma pessoa? S/N");
		Scanner leia = new Scanner(System.in);
		String controle = leia.next();
		if (controle.equals("S")) {

			System.out.println("Qual o nome?");
			String nome = leia.next();
			pessoa.setNome(nome);

			System.out.println("Qual a data de nascimento?");
			String data = leia.next();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date dataNcto = sdf.parse(data);
			pessoa.setDataNcto(dataNcto);

			System.out.println("Qual o g�nero?");
			String genero = leia.next();
			pessoa.setGenero(genero);

			System.out.println("Qual o CPF?");
			String cpf = leia.next();
			pessoa.setCpf(cpf);

			System.out.println("Qual o endere�o?");
			String endereco = leia.next();
			pessoa.setEndereco(endereco);

			Pessoa conjuge = new Pessoa(null, null, null, null, null, pessoa);
			
			System.out.println("Qual o nome do c�njuge?");
			String nomeC = leia.next();
			conjuge.setNome(nomeC);

			System.out.println("Qual a data de nascimento do c�njuge?");
			String dataC = leia.next();
			Date dataNctoC = sdf.parse(dataC);
			conjuge.setDataNcto(dataNctoC);

			System.out.println("Qual o g�nero do c�njuge?");
			String generoC = leia.next();
			conjuge.setGenero(generoC);

			System.out.println("Qual o CPF do c�njuge?");
			String cpfC = leia.next();
			conjuge.setCpf(cpfC);

			System.out.println("Qual o endere�o do c�njuge?");
			String enderecoC = leia.next();
			conjuge.setEndereco(enderecoC);
			
			System.out.println(pessoa.imprimirConjuge());
			System.out.println(conjuge.imprimirConjuge());
		}

	}

}
