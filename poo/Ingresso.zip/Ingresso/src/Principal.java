import java.text.SimpleDateFormat;
import java.util.Date;

public class Principal {

	public static void main(String[] args) {
		
		Usuario usuarioJ = new Usuario ("Jo�o", "333.333.333", 16);
		Usuario usuarioA = new Usuario ("Artur", "888.888.888", 68);
		
		Date data = new Date();
		Evento evento = new Evento ("show", data, "show de Jorge Drewler");
		
		Ingresso ingressoA = new Ingresso("setorAmarelo", "EMABERTO", 32, 70.00, evento);
		Ingresso ingressoB = new Ingresso("setorAzul", "EMABERTO", 78, 120.00, evento);
		Ingresso ingressoC = new Ingresso("setorVermelho", "EMABERTO", 129, 300.00, evento);
			
		ingressoA.calcularValorTotal(usuarioA);
		ingressoB.calcularValorTotal(usuarioJ);
		ingressoC.calcularValorTotal(usuarioA);
				
		ingressoA.comprarIngresso(usuarioA);
		ingressoB.comprarIngresso(usuarioJ);
		ingressoC.comprarIngresso(usuarioA);
		
		System.out.println(ingressoA.getUsuario().getNome() + "\n" + evento.imprimirDadosEvento(ingressoA));
		System.out.println(ingressoB.getUsuario().getNome() + "\n" + evento.imprimirDadosEvento(ingressoB));
		System.out.println(ingressoC.getUsuario().getNome() + "\n" + evento.imprimirDadosEvento(ingressoC));
		
	}

}
