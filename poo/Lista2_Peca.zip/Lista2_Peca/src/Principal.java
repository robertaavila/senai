import java.util.ArrayList;
import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {

		Peca peca = new Peca(null, 0, null);
		ArrayList<Peca> listaPecas = new ArrayList<Peca>();

		Scanner leia = new Scanner(System.in);
		System.out.println("Qual o nome da pe�a?");
		String nome = leia.next();
		peca.setNome(nome);

		System.out.println("Qual a quantidade de pe�as?");
		int creditos = leia.nextInt();
		peca.setQuantidade(creditos);

		System.out.println("Insira uma descri��o da pe�a: ");
		String descricao = leia.next();
		peca.setDescricao(descricao);

		String repetir = "S";
		System.out.println("A pe�a � composta por outras pe�as?");
		repetir = leia.next(); 
	
		do {
			if (repetir.equals("S")) {
				Integer contador = 0;
				contador++;
				Peca componente = new Peca(null, 0, null);

				System.out.println("Qual o nome da pe�a?");
				String nomeP = leia.next();
				componente.setNome(nomeP);

				System.out.println("Qual a quantidade de pe�as?");
				int quantidadeP = leia.nextInt();
				componente.setQuantidade(quantidadeP);

				System.out.println("Insira uma descri��o da pe�a: ");
				String descricaoP = leia.next();
				componente.setDescricao(descricaoP);

				listaPecas.add(componente);

				System.out.println("Deseja inserir mais pe�as componentes?");
				repetir = leia.next();
				
			} 
		} while (repetir.equals("S"));

		peca.setListaPecas(listaPecas);

		peca.imprimir();

		for (int i = 0; i < listaPecas.size(); i++) {
			listaPecas.get(i).imprimir();
		}		
	}
}
