import java.util.ArrayList;

public class Peca {

	private String nome;
	private int quantidade;
	private String descricao;
	ArrayList<Peca> listaPecas;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public ArrayList<Peca> getListaPecas() {
		return listaPecas;
	}

	public void setListaPecas(ArrayList<Peca> listaPecas) {
		this.listaPecas = listaPecas;
	}

	public Peca(String nome, int quantidade, String descricao) {
		this.nome = nome;
		this.quantidade = quantidade;
		this.descricao = descricao;
	}

	public void imprimir() {
		System.out.println(
				"Nome da pe�a: " + nome + "\n" + "Quantidade: " + quantidade + "\n" + "Descri��o: " + descricao + "\n");
	}
}
