import java.util.ArrayList;
import java.util.Scanner;

public class Pais {

	private String pais;
	private String capital;
	private Double dimensao;
	private ArrayList<String> fronteira;
	private String nomePais;
	private String resultado;
	private String listaFronteiraComum;
	private int contador;

	public Pais(String pais, String capital, Double dimensao, ArrayList<String> fronteira) {
		this.pais = pais;
		this.capital = capital;
		this.dimensao = dimensao;
		this.fronteira = fronteira;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public String getCapital() {
		return capital;
	}

	public void setCapital(String capital) {
		this.capital = capital;
	}

	public Double getDimensao() {
		return dimensao;
	}

	public void setDimensao(Double dimensao) {
		this.dimensao = dimensao;
	}

	public ArrayList<String> getFronteira() {
		return fronteira;
	}

	public void setFronteira(ArrayList<String> fronteira) {
		this.fronteira = fronteira;
	}

	public String checarFronteira(String paisFronteira) {
		for (int i = 0; i < fronteira.size(); i++) {
			if (fronteira.get(i).equals(nomePais)) {
				resultado = "Os pa�ses t�m uma fronteira m�tua.";
			} else {
				resultado = "Os pa�ses n�o fazem fronteira.";
			}
		}
		return resultado;
	}
	
	public String fronteiraComum(Object Pais) {
		for (int i = 0; i < fronteira.size(); i++) {
			if (fronteira.get(i).equals(nomePais)) {
				listaFronteiraComum += fronteira.get(i) + " ";
				contador++;
			} 
			if (contador > 0) {
				resultado = "Os pa�ses com os quais ambos t�m fronteira s�o: ";
			} else {
				resultado = "Estes pa�ses n�o tem fronteira em comum. ";
			}
		
		}
		return resultado + listaFronteiraComum;
	}
	
}