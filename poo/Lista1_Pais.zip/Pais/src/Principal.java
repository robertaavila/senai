import java.util.ArrayList;
import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {

		Pais p1 = new Pais(null, null, null, null);

		System.out.println("Qual o nome do pa�s?");
		Scanner leiaString = new Scanner(System.in);
		String pais = leiaString.next();
		p1.setPais(pais);

		System.out.println("Qual o nome da capital do pa�s?");
		String capital = leiaString.next();
		p1.setCapital(capital);

		System.out.println("Qual a dimens�o do pa�s?");
		Scanner leiaDouble = new Scanner(System.in);
		Double dimensao = leiaDouble.nextDouble();
		p1.setDimensao(dimensao);

		System.out.println("Quantos pa�ses fazem fronteira com este pa�s?");
		Scanner leia = new Scanner(System.in);
		int limite = leia.nextInt();

		int i;
		ArrayList<String> fronteira = new ArrayList<String>();
		for (i = 0; i < limite; i++) {
			System.out.println("Insira o nome do pa�s que faz fronteira com o pa�s atual: ");
			String lista = leiaString.next();
			fronteira.add(lista);
			p1.setFronteira(fronteira);
		}

		System.out.println("Deseja comparar um novo pa�s com o pa�s inserido? S/N");
		String controle = leiaString.next();
		if (controle.equals("S")) {
			System.out.println("Qual o nome do pa�s a ser comparado?");
			String novoPais = leiaString.next();
			System.out.println("Qual o nome da capital do pa�s a ser comparada?");
			String novaCapital = leiaString.next();
			if (p1.getPais().equals(novoPais) && p1.getCapital().equals(novaCapital)) {
				System.out.println("Os pa�ses s�o iguais.\n");
			} else {
				System.out.println("Os pa�ses s�o diferentes.\n");
			}

		}
		
		System.out.println("Deseja verificar se um pa�s faz fronteira o com o objeto atual? S/N");
		controle = leiaString.next();
		if (controle.equals("S")) {
			System.out.println("Qual o nome do pa�s a ser comparado?");
			String nomePais = leiaString.next();
			System.out.println(p1.checarFronteira(nomePais));
		

		}
	}
	
}
