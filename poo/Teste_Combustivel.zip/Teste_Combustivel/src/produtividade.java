import java.util.Scanner;

public class produtividade {

	public static void main(String[] args) {
		double Gasolina = 0.0;
		double Alcool = 0.0; 
		String valorGasolina = "Digite o pre�o da gasolina em R$: ";
		String valorAlcool = "Digite o pre�o do �lcool em R$: ";
		String valorInvalido = "Pre�o inv�lido.";
		boolean continuar = true;
		
		while(continuar) {
			System.out.println("Bem vindo � calculadora Gasolina/Etanol");
			System.out.println(valorGasolina);
	
			Scanner leiaG = new Scanner(System.in);
			int gasolina = leiaG.nextInt();
	
			while(gasolina < 0.01 || gasolina > 10){
				System.out.println(valorInvalido + "\n" + valorGasolina);
				gasolina = leiaG.nextInt();	
			} 
			System.out.println(valorAlcool);
			
			Scanner leiaA = new Scanner(System.in);
			int alcool = leiaA.nextInt();
	
			while(alcool < 0.01 || alcool > 10){
				System.out.println(valorInvalido + "\n" + valorAlcool);
				alcool = leiaA.nextInt();
			} 	
			
			if(alcool/gasolina > 0.73){
				System.out.println("O combust�vel com melhor rentabilidade � a gasolina.");
			} else {
				System.out.println("O combust�vel com melhor rentabilidade � o �lcool.");
			}
			
			System.out.println("\nDeseja continuar? Digite S ou N: ");
			Scanner leia = new Scanner(System.in);
			String controle = leia.next();
			
			if(controle == "N" || controle == "n") {
				continuar = false;
				System.out.println("Programa encerrado");	

			}
		}		
	}
}
	
