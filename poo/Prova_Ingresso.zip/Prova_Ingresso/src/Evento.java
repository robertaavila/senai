import java.text.SimpleDateFormat;
import java.util.Date;

public class Evento {

	private String descricao;
	private Date dataEvento;
	private String resumo;
	private Ingresso ingresso;
	
	public Evento(String descricao, Date dataEvento, String resumo) {
		this.descricao = descricao;
		this.dataEvento = dataEvento;
		this.resumo = resumo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Date getDataEvento() {
		return dataEvento;
	}

	public void setDataEvento(Date dataEvento) {
		this.dataEvento = dataEvento;
	}

	public String getResumo() {
		return resumo;
	}

	public void setResumo(String resumo) {
		this.resumo = resumo;
	}
	
	public String imprimirDadosEvento(Ingresso ingresso) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String imprimir = "Descri��o: " + descricao + "\n" +
				"Data: " + sdf.format(getDataEvento()) + "\n"+ 
				"Resumo: " + resumo + "\n"  
				+ ingresso.getIngressoVendido() +"\n";	
		return imprimir; 
		
	}

}
