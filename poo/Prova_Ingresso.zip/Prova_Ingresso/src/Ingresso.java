
public class Ingresso {

	private String setor;
	private String situacao;
	private int cadeiraNumerada;
	private Double valorUnitario;
	private Double valorTotal;
	private int idade;
	private Usuario usuario;
	private Evento evento;
	private int ingressoVendido;

	public Ingresso(String setor, String situacao, int cadeiraNumerada, Double valorUnitario, Evento evento) {
		this.setor = setor;
		this.situacao = situacao;
		this.cadeiraNumerada = cadeiraNumerada;
		this.valorUnitario = valorUnitario;
		this.evento = evento;
	}

	public String getSetor() {
		return setor;
	}

	public void setSetor(String setor) {
		this.setor = setor;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	public int getCadeiraNumerada() {
		return cadeiraNumerada;
	}

	public void setCadeiraNumerada(int cadeiraNumerada) {
		this.cadeiraNumerada = cadeiraNumerada;
	}

	public Double getValorUnitario() {
		return valorUnitario;
	}

	public void setValorUnitario(Double valorUnitario) {
		this.valorUnitario = valorUnitario;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public int getIngressoVendido() {
		return ingressoVendido;
	}

	public void setIngressoVendido(int ingressoVendido) {
		this.ingressoVendido = ingressoVendido;
	}

	public void comprarIngresso(Usuario usuario) {
		this.usuario = usuario;
		situacao = "VENDIDO";
		ingressoVendido++;
	}

	public Double calcularValorTotal(Usuario usuario) {
		usuario.getIdade();
		if (idade < 18 || idade > 65) {
			valorUnitario *= 0.5;
			valorTotal = valorUnitario;
		} else {
			valorUnitario = valorTotal;
		}
		return valorTotal;

	}
}