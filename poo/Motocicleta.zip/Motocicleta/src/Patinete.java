
public class Patinete {

	public String cor;
	public double precoPatinete;
	public int duracaoBateria;
	
	public Patinete(String cor, double precoPatinete, int duracaoBateria) {
		this.cor = cor;
		this.precoPatinete = precoPatinete;
		this.duracaoBateria = duracaoBateria;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	public double getPrecoPatinete() {
		return precoPatinete;
	}

	public void setPrecoPatinete(double precoPatinete) {
		this.precoPatinete = precoPatinete;
	}

	public int getDuracaoBateria() {
		return duracaoBateria;
	}

	public void setDuracaoBateria(int duracaoBateria) {
		this.duracaoBateria = duracaoBateria;
	}

	
}
