
public class Motocicleta {

	public double preco;
	public double cilindradas;
	public int parcelamento;
	
	public Motocicleta(double preco, double cilindradas, int parcelamento) {
		super();
		this.preco = preco;
		this.cilindradas = cilindradas;
		this.parcelamento = parcelamento;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public double getCilindradas() {
		return cilindradas;
	}

	public void setCilindradas(double cilindradas) {
		this.cilindradas = cilindradas;
	}

	public int getParcelamento() {
		return parcelamento;
	}

	public void setParcelamento(int parcelamento) {
		this.parcelamento = parcelamento;
	}
}