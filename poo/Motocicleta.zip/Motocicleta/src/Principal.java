
public class Principal {

	public static void main(String[] args) {
		Motocicleta harley = new Motocicleta(5000.0, 500, 5);
		
		System.out.println("Moto " + harley.cilindradas + " cilindradas. Pre�o:" + 
				harley.preco + " Parcelamento em " + harley.parcelamento + " vezes.");

		Patinete grin = new Patinete("green", 2.500, 3);
		
		System.out.println("O patinete �: " + grin.cor + ", a bateria dura " + 
				grin.duracaoBateria + " horas e o pre�o do patinete �: " + grin.precoPatinete);
	
	} 
}

