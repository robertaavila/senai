import java.util.ArrayList;

public class Disciplina {

	private String nome;
	private int creditos;
	private int fase;
	ArrayList<Disciplina> listaDisciplinas;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getCreditos() {
		return creditos;
	}

	public void setCreditos(int creditos) {
		this.creditos = creditos;
	}

	public int getFase() {
		return fase;
	}

	public void setFase(int fase) {
		this.fase = fase;
	}

	public ArrayList<Disciplina> getListaDisciplinas() {
		return listaDisciplinas;
	}

	public void setListaDisciplinas(ArrayList<Disciplina> listaDisciplinas) {
		this.listaDisciplinas = listaDisciplinas;
	}

	public Disciplina(String nome, int creditos, int fase) {
		this.nome = nome;
		this.creditos = creditos;
		this.fase = fase;
	}

	public void imprimir() {
		System.out.println("Nome da disciplina: " + nome + "\n"
				+ "Cr�ditos: " + creditos + "\n"		
				+ "Fase: " + fase + "\n");
	}
}
