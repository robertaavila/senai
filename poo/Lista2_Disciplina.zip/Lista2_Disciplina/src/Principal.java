import java.util.ArrayList;
import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {

		Disciplina disciplina = new Disciplina(null, 0, 0);
		ArrayList<Disciplina> listaDisciplinas = new ArrayList<Disciplina>();

		Scanner leia = new Scanner(System.in);
		System.out.println("Qual o nome da disciplina?");
		String nome = leia.next();
		disciplina.setNome(nome);

		System.out.println("Quantos cr�ditos tem a disciplina?");
		int creditos = leia.nextInt();
		disciplina.setCreditos(creditos);

		System.out.println("Em qual fase a disciplina � oferecida?");
		int fase = leia.nextInt();
		disciplina.setFase(fase);

		String repetir = "S";

		do {
			System.out.println("A disciplina cadastrada tem pr�-requisitos?");
			repetir = leia.next(); 
			if (repetir.equals("S")) {
				Integer contador = 0;
				contador++;
				Disciplina preRequisito = new Disciplina(null, 0, 0);

				System.out.println("Qual o nome do pr�-requisito?");
				String nomeP = leia.next();
				preRequisito.setNome(nomeP);

				System.out.println("Quantos cr�ditos tem o pr�-requisito?");
				int creditosP = leia.nextInt();
				preRequisito.setCreditos(creditosP);

				System.out.println("Em qual fase a disciplina pr�-requito � oferecida?");
				int faseP = leia.nextInt();
				preRequisito.setFase(faseP);

				listaDisciplinas.add(preRequisito);

				System.out.println("Deseja inserir mais um pr�-requisito?");
				repetir = leia.next();
			} 
		} while (repetir.equals("S"));

		disciplina.setListaDisciplinas(listaDisciplinas);

		disciplina.imprimir();

		for (int i = 0; i < listaDisciplinas.size(); i++) {
			listaDisciplinas.get(i).imprimir();
		}		
	}
}
