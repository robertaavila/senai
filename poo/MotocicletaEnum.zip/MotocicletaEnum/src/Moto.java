
public class Moto {

	private String marca;
	private String nome;
	private int quantidade;
	private MotocicletaEnum moto;

	public Moto(String marca, String nome, int quantidade, MotocicletaEnum moto) {
		this.marca = marca;
		this.nome = nome;
		this.quantidade = quantidade;
		this.moto = moto;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	public MotocicletaEnum getMoto() {
		return moto;
	}
	public void setMoto(MotocicletaEnum moto) {
		this.moto = moto;
	}

	
}
