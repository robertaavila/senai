
public enum MotocicletaEnum {
	
	DESMONTADA("Desmontada"),
	MONTADA("Montada"),
	EMEXPOSI�AO("Exposi��o"),
	VENDIDA("VEndida");
	
	private final String nome;

	private MotocicletaEnum(String nome) {
		this.nome = nome;
	}

	public String getNome() {
		return nome;
	}
}
