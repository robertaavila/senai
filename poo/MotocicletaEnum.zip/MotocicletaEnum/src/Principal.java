
public class Principal {

	public static void main(String[] args) {
		
		Moto moto = new Moto("Suzuki", "12345", 5, MotocicletaEnum.DESMONTADA);
		
		Moto moto1 = new Moto("Bis", "4567", 4, MotocicletaEnum.EMEXPOSI�AO);
		
		Moto moto2 = new Moto("Vespa", "7990", 9, MotocicletaEnum.MONTADA);
				
		Moto moto3 = new Moto("Harley", "09234", 3, MotocicletaEnum.VENDIDA);
		
		System.out.println(moto.getMoto().getNome());
		
	}
}
