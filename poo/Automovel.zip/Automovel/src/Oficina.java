
public class Oficina {

	private String nome;
	private int caixa;
	private String servico;
	private int horasSemanais;
	
	public Oficina(String nome, int caixa, String servico, int horasSemanais) {
		this.nome = nome;
		this.caixa = caixa;
		this.servico = servico;
		this.horasSemanais = horasSemanais;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public int getCaixa() {
		return caixa;
	}
	
	public void setCaixa(int caixa) {
		this.caixa = caixa;
	}
	
	public String getServico() {
		return servico;
	}
	
	public void setServico(String servico) {
		this.servico = servico;
	}
	
	public int getHorasSemanais() {
		return horasSemanais;
	}
	
	public void setHorasSemanais(int horasSemanais) {
		this.horasSemanais = horasSemanais;
	}

}
