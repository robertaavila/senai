import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		Scanner leia = new Scanner(System.in);

		//cria uma inst�ncia de autom�vel	
		Automovel a1 = new Automovel("Amarelo", "Ford", "Opala");
		
		System.out.println(a1.cor + "-" + a1.modelo + "-" + a1.marca);		
		
		a1.setCor("AZUL");
		System.out.println(a1.getCor());
		
		Oficina oficina = new Oficina("Oficina do Sul", 200, "Reparo de lataria", 40);
		
		System.out.println(oficina.getCaixa() + "-" + oficina.getNome() + "-" + oficina.getServico());
		
	}
	
}
